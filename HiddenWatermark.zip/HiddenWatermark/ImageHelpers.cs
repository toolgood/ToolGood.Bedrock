﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToolGood.Bedrock.Images.HiddenWatermark
{
    internal class ImageHelpers
    {
        //internal bool ClipSupport { get; set; }

        private delegate double ColorConversion(double red, double green, double blue);
        private const int PaddingLimit = 10;

        //private int[] _clippingWidths = new int[] { 1024, 911, 832, 800, 744, 700, 640, 600, 568, 508, 480, 448, 400, 360, 333 };
        //private int[] _clippingHeights = new int[] { 768, 683, 624, 600, 558, 525, 480, 450, 426, 373, 360, 336, 300, 270, 250 };

        public ImageHelpers(bool clipSupport, IEnumerable<int> widths, IEnumerable<int> heights)
        {
            //ClipSupport = clipSupport;
            //if (widths != null)
            //    _clippingWidths = widths.ToArray();
            //if (heights != null)
            //    _clippingHeights = heights.ToArray();
        }

        public byte[] MergeWatermarkPixels(Bitmap image, Bitmap watermark)
        {
            var pixelSize = 3;
            var width = image.Width;
            var height = image.Height;

            var wmPixels = ScaleWatermark(watermark, width, height);

            byte[] pixels = GetBytes(image);

            Parallel.For(0, width, w => {
                var hPos = w * height * pixelSize;
                for (int h = 0; h < height * pixelSize; h += pixelSize) {
                    var i = hPos + h;

                    bool nextSame = false, prevSame = false;
                    if (i > 0 && pixels[i] == pixels[i - pixelSize] && pixels[i + 1] == pixels[i + 1 - pixelSize]) {
                        nextSame = true;
                    }
                    if (i + pixelSize < pixels.Length && pixels[i] == pixels[i + pixelSize] && pixels[i + 1] == pixels[i + 1 + pixelSize]) {
                        prevSame = true;
                    }

                    if (!nextSame || !prevSame) {
                        pixels[i] = ToByte(pixels[i] + 128 - wmPixels[i]);
                        pixels[i + 1] = ToByte(pixels[i + 1] + 128 - wmPixels[i + 1]);
                        //pixels[i + 2] = ToByte(pixels[i + 2] + 128 - wmPixels[i + 2]);
                    }
                }
            });
            using (var ms = new MemoryStream()) {
                var image2 = CreateImage(pixels, width, height);
                image2.Save(ms, ImageFormat.Jpeg);
                return ms.ToArray();
            }
        }





        private byte[] ScaleWatermark(Bitmap originalImage, int width, int height)
        {
            int towidth = width;
            int toheight = height;
            int ow = originalImage.Width;
            int oh = originalImage.Height;

            int x = 0;
            int y = 0;
            //if ((double)originalImage.Width / (double)originalImage.Height > (double)towidth / (double)toheight) {
            //    ow = originalImage.Width;
            //    oh = originalImage.Width * height / towidth;
            //    x = 0;
            //    y = (originalImage.Height - oh) / 2;
            //} else {
            //    oh = originalImage.Height;
            //    ow = originalImage.Height * towidth / toheight;
            //    y = 0;
            //    x = (originalImage.Width - ow) / 2;
            //}


            Bitmap b = new Bitmap(towidth, toheight);
            Graphics g = Graphics.FromImage(b);
            //设置高质量插值法
            g.InterpolationMode = InterpolationMode.Default;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = SmoothingMode.None;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(Color.White);
            g.DrawImage(originalImage, new Rectangle(0, 0, towidth, toheight), new Rectangle(x, y, ow, oh), GraphicsUnit.Pixel);

            return GetBytes(b);
        }


        public byte[] SavePixels(RgbData data)
        {
            var width = data.R.GetUpperBound(0) + 1;
            var height = data.R.GetUpperBound(1) + 1;
            var pixelSize = 3;

            byte[] pixels = new byte[width * pixelSize * height];
            Parallel.For(0, width, w => {
                var hPos = w * height * pixelSize;
                for (int h = 0; h < height; h++) {
                    var i = hPos + (h * pixelSize);

                    pixels[i] = ToByte(data.B[w, h]);
                    pixels[i + 1] = ToByte(data.G[w, h]);
                    pixels[i + 2] = ToByte(data.R[w, h]);
                }
            });

            return pixels;

            //using (var ms = new MemoryStream()) {
            //    var image2 = CreateImage(pixels, width, height);
            //    image2.Save(ms, ImageFormat.Jpeg);
            //    return ms.ToArray();
            //}

            //var frame = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgr32, BitmapPalettes.WebPalette);
            //frame.WritePixels(new Int32Rect(0, 0, width, height), pixels, width * pixelSize, 0);

            //using (var encoderMemoryStream = new MemoryStream()) {
            //    var encoder = new JpegBitmapEncoder();
            //    encoder.Frames.Add(BitmapFrame.Create(frame));
            //    encoder.Save(encoderMemoryStream);

            //    return encoderMemoryStream.ToArray();
            //}
        }

        public double[,] ExtractWatermarkData(Bitmap bitmap, int width, int height)
        {
            Bitmap b = new Bitmap(width, height);
            Graphics g = Graphics.FromImage(b);
            //设置高质量插值法
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(Color.White);
            g.DrawImage(bitmap, new Rectangle(0, 0, bitmap.Width, height), new Rectangle(0, 0, width, height), GraphicsUnit.Pixel);

            return ReadPixels(b, ColorSpaceConversion.RgbToU);



            ////var bitmap = CreateImage(bytes, width, height);
            //var paddingW = GetPaddingW(bitmap.Width);
            //var paddingH = GetPaddingH(bitmap.Height);



            ////var decoder = BitmapDecoder.Create(decoderMemoryStream, BitmapCreateOptions.None, BitmapCacheOption.Default);
            ////var frame = decoder.Frames[0];
            ////var paddingW = GetPaddingW(frame.PixelWidth);
            ////var paddingH = GetPaddingH(frame.PixelHeight);

            //var newWidth = (int)Math.Round((bitmap.Width / (double)(bitmap.Width + paddingW)) * width);
            //var newHeight = (int)Math.Round((bitmap.Height / (double)(bitmap.Height + paddingH)) * height);

            //var image = CreateImage(bytes, newWidth, newHeight);
            //return ReadPixels(image, ColorSpaceConversion.RgbToU);

        }

        private static Bitmap CreateImage(byte[] bytes, int decodePixelWidth = 32, int decodePixelHeight = 32)
        {
            if (bytes == null) return null;
            return ToColorBitmap(bytes, decodePixelWidth, decodePixelHeight);
            //Bitmap result = new Bitmap();
            //result.BeginInit();

            //if (decodePixelWidth > 0)
            //    result.DecodePixelWidth = decodePixelWidth;

            //if (decodePixelHeight > 0)
            //    result.DecodePixelHeight = decodePixelHeight;

            //result.StreamSource = new MemoryStream(bytes);
            //result.CreateOptions = BitmapCreateOptions.None;
            //result.CacheOption = BitmapCacheOption.Default;
            //result.EndInit();

            //return result;
        }

        private int GetPaddingW(int width)
        {
            return 0;
            //if (!ClipSupport) return 0;

            //int padding = 0;
            //for (int i = 0; i < _clippingWidths.Length; i++) {
            //    if (width > _clippingWidths[i] + PaddingLimit) {
            //        padding = i == 0 ? 0 : _clippingWidths[i - 1] - width;
            //        break;
            //    }
            //}

            //return Math.Max(0, padding);
        }

        private int GetPaddingH(int height)
        {
            return 0;

            //if (!ClipSupport) return 0;

            //int padding = 0;
            //for (int i = 0; i < _clippingHeights.Length; i++) {
            //    if (height > _clippingHeights[i] + PaddingLimit) {
            //        padding = i == 0 ? 0 : _clippingHeights[i - 1] - height;
            //        break;
            //    }
            //}

            //return Math.Max(0, padding);
        }

        public RgbData ReadPixels(Bitmap source)
        {
            var width = source.Width;
            var height = source.Height;
            var pixelSize = 3;
            byte[] pixels = GetBytes(source);

            double[,] R = new double[width, height];
            double[,] G = new double[width, height];
            double[,] B = new double[width, height];

            Parallel.For(0, width, w => {
                var hPos = w * height * pixelSize;
                for (int h = 0; h < height; h++) {
                    var i = hPos + (h * pixelSize);

                    var gray = pixelSize == 1 ? pixels[i] : 0;
                    B[w, h] = pixelSize >= 3 ? pixels[i] : gray;
                    G[w, h] = pixelSize >= 3 ? pixels[i + 1] : gray;
                    R[w, h] = pixelSize >= 3 ? pixels[i + 2] : gray;
                }
            });

            return new RgbData(R, G, B);
        }

        private double[,] ReadPixels(Bitmap source, ColorConversion convert)
        {
            int width = source.Width;
            int height = source.Height;
            var pixelSize = 3;
            byte[] pixels = GetBytes(source);

            double[,] data = new double[width, height];
            Parallel.For(0, width, w => {
                var hPos = w * height * pixelSize;
                for (int h = 0; h < height; h++) {
                    var i = hPos + (h * pixelSize);

                    var gray = pixelSize == 1 ? pixels[i] : 0;

                    var blue = pixelSize >= 3 ? pixels[i] : gray;
                    var green = pixelSize >= 3 ? pixels[i + 1] : gray;
                    //var red = pixelSize >= 3 ? pixels[i + 2] : gray; //U doesn't use Red

                    data[w, h] = convert(255, green, blue);
                }
            });

            return data;
        }

        private byte ToByte(double input)
        {
            if (input < 0)
                return 0;
            if (input > 255)
                return 255;
            return (byte)input;
        }



        /// <summary>
        /// 将数组转换成彩色图片
        /// </summary>
        /// <param name="rawValues">图像的byte数组</param>
        /// <param name="width">图像的宽</param>
        /// <param name="height">图像的高</param>
        /// <returns>Bitmap对象</returns>
        public static Bitmap ToColorBitmap(byte[] rawValues, int width, int height)
        {
            //// 申请目标位图的变量，并将其内存区域锁定
            try {
                var m_currBitmap = new Bitmap(width, height, PixelFormat.Format24bppRgb);
                var m_rect = new Rectangle(0, 0, width, height);
                var m_bitmapData = m_currBitmap.LockBits(m_rect, ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

                IntPtr iptr = m_bitmapData.Scan0;  // 获取bmpData的内存起始位置  
                System.Runtime.InteropServices.Marshal.Copy(rawValues, 0, iptr, width * height * 3);
                m_currBitmap.UnlockBits(m_bitmapData);

                return m_currBitmap;
            } catch (System.Exception ex) {
                return null;
            }
        }


        private static byte[] GetBytes(Bitmap bitmap)
        {
            var length = bitmap.Width * bitmap.Height * 3;
            byte[] rawValues = new byte[length];
            var m_rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            var m_bitmapData = bitmap.LockBits(m_rect, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            IntPtr iptr = m_bitmapData.Scan0;  // 获取bmpData的内存起始位置  
            System.Runtime.InteropServices.Marshal.Copy(iptr, rawValues, 0, length);
            bitmap.UnlockBits(m_bitmapData);
            return rawValues;
        }


    }

}
